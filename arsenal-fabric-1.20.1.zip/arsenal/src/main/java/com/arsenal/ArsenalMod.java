package com.arsenal;

import net.fabricmc.api.ModInitializer;

public class ArsenalMod implements ModInitializer {
    public static final String MOD_ID = "arsenal";

    @Override
    public void onInitialize() {
        ModItems.register();
    }
}
