package com.arsenal.mixin;

import com.arsenal.ModItems;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {

    // ---- ค่าที่ปรับได้ (ถ้าดาบไม่ตรงมือ ให้แก้ตรงนี้) ----
    private static final float ITEM_X = 0.56f;   // ซ้าย-ขวา
    private static final float ITEM_Y = -0.46f;  // ขึ้น-ลง
    private static final float ITEM_Z = -0.72f;  // ใกล้-ไกล
    private static final float SWEEP_DEG = 60f;  // องศาการฟันแนวนอน
    private static final float TILT_DEG = 35f;   // องศาเฉียง
    private static final float LIFT_DEG = 40f;   // องศาง้าง/ยกขึ้น

    @Shadow
    protected abstract void renderArmHoldingItem(MatrixStack matrices, VertexConsumerProvider vcp, int light,
                                                 float equipProgress, float swingProgress, Arm arm);

    @Shadow
    public abstract void renderItem(LivingEntity entity, ItemStack stack, ModelTransformationMode mode,
                                    boolean leftHanded, MatrixStack matrices, VertexConsumerProvider vcp, int light);

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), cancellable = true)
    private void arsenal$renderBlade(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand,
                                     float swing, ItemStack stack, float equip, MatrixStack matrices,
                                     VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (!stack.isOf(ModItems.IRON_BLADE)) return;
        ci.cancel();

        Arm arm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        boolean right = arm == Arm.RIGHT;
        float f = right ? 1f : -1f;

        // a: -1 (ง้าง) -> +1 (ฟันสุด) -> 0 (กลับท่า)
        float a;
        if (swing <= 0f) a = 0f;
        else if (swing < 0.2f) a = -ease(swing / 0.2f);
        else if (swing < 0.7f) a = -1f + 2f * easeOut((swing - 0.2f) / 0.5f);
        else a = 1f - ease((swing - 0.7f) / 0.3f);

        // ----- แขน -----
        matrices.push();
        applySlash(matrices, f, a, swing);
        renderArmHoldingItem(matrices, vcp, light, equip, 0f, arm);
        matrices.pop();

        // ----- ดาบ -----
        matrices.push();
        applySlash(matrices, f, a, swing);
        matrices.translate(f * ITEM_X, ITEM_Y + equip * -0.6f, ITEM_Z);
        renderItem(player, stack,
                right ? ModelTransformationMode.FIRST_PERSON_RIGHT_HAND : ModelTransformationMode.FIRST_PERSON_LEFT_HAND,
                !right, matrices, vcp, light);
        matrices.pop();
    }

    private static void applySlash(MatrixStack m, float f, float a, float swing) {
        if (swing <= 0f) return;
        float lunge = MathHelper.sin(swing * (float) Math.PI) * 0.25f;
        m.translate(0f, 0f, -lunge);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(f * a * SWEEP_DEG));
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(f * a * TILT_DEG));
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-Math.max(0f, -a) * LIFT_DEG));
    }

    private static float ease(float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        return t * t * (3f - 2f * t);
    }

    private static float easeOut(float t) {
        t = MathHelper.clamp(t, 0f, 1f);
        float u = 1f - t;
        return 1f - u * u * u;
    }
}
