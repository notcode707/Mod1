package com.arsenal;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class ModItems {
    public static final Item IRON_BLADE = new SwordItem(ToolMaterials.IRON, 3, -2.4f, new Item.Settings());

    public static void register() {
        Registry.register(Registries.ITEM, new Identifier(ArsenalMod.MOD_ID, "iron_blade"), IRON_BLADE);
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(e -> e.add(IRON_BLADE));
    }
}
